# Algoritimo I

A malição do Castelo.

Descrição :
Uma historia interativa de multipla escolha, 
que monsta caminhos e desafios com dois finais.

Recurso :
-C++
-Switch
-If, else, else If.
-Variaveis
